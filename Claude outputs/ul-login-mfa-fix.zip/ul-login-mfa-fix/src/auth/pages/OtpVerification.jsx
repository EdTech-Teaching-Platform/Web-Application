// OTP / Email Verification + Admin/Super Admin 2FA — LMS doc Sec 5.1.
// Two modes now, sharing one screen since the UI is otherwise identical:
//   mode=register — verifying a brand-new account right after Register.
//     Platform-sent code: shows the masked destination, has a resend
//     timer.
//   mode=mfa      — mandatory post-login TOTP step for Admin/Super Admin
//     only (not Student/Educator — see LMS doc's Admin MFA feature). The
//     code comes from the user's own authenticator app, not the platform,
//     so this mode has no masked destination, no "we sent a code" copy,
//     and no resend button/timer — none of that makes sense for a
//     locally-generated code.
// mode=login-otp (OTP as an alternative way to log in) has been removed —
// the Login screen no longer offers that toggle; see Login.jsx.
import { useEffect, useState } from "react";
import { Link, useNavigate, useSearchParams } from "react-router-dom";
import AuthCard from "../components/AuthCard";
import Button from "../../components/ui/Button";
import OtpInput from "../../components/ui/OtpInput";
import { identifierKind, maskDestination } from "../utils/validators";
import { verifyAccountOtp, verifyMfaCode, resendOtp } from "../services/authApi";

const RESEND_SECONDS = 60;

export default function OtpVerification() {
  const [params] = useSearchParams();
  const navigate = useNavigate();
  const mode = params.get("mode") === "mfa" ? "mfa" : "register";
  const destination = params.get("destination") || "";

  const [code, setCode] = useState("");
  const [error, setError] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [cooldown, setCooldown] = useState(RESEND_SECONDS);

  useEffect(() => {
    if (mode !== "register" || cooldown <= 0) return;
    const id = setInterval(() => setCooldown((s) => s - 1), 1000);
    return () => clearInterval(id);
  }, [mode, cooldown]);

  const kind = identifierKind(destination) || "email";
  const masked = destination ? maskDestination(destination) : kind === "email" ? "your email" : "your phone";

  const handleVerify = async (e) => {
    e.preventDefault();
    if (code.length !== 6) return;
    setSubmitting(true);
    setError("");
    try {
      if (mode === "mfa") {
        await verifyMfaCode({ identifier: destination, code });
        // Only Admin/Super Admin reach this mode — route to the admin
        // portal once verified. Student/Educator never hit this step.
        navigate("/admin");
      } else {
        await verifyAccountOtp({ identifier: destination, code });
        // Onboarding happens before verification, not after — this
        // completes account creation, so route straight to the dashboard.
        navigate("/student/dashboard");
      }
    } catch {
      setError("That code didn't work — check and try again.");
    } finally {
      setSubmitting(false);
    }
  };

  const handleResend = async () => {
    if (cooldown > 0) return;
    setError("");
    try {
      await resendOtp({ identifier: destination, purpose: "register" });
      setCooldown(RESEND_SECONDS);
    } catch {
      setError("Couldn't resend the code. Please try again in a moment.");
    }
  };

  const isMfa = mode === "mfa";
  const backHref = isMfa ? "/login" : "/student/onboarding";
  const backLabel = isMfa
    ? "Back to login"
    : kind === "email"
      ? "Use a different email"
      : "Use a different phone number";

  return (
    <AuthCard
      eyebrow={isMfa ? "Two-Factor Verification" : "Verify"}
      title={isMfa ? "Enter your authenticator code" : `Verify your ${kind}`}
      subtitle={
        isMfa
          ? "Enter the 6-digit code from your authenticator app."
          : `We sent a code to ${masked}.`
      }
      footer={
        <Link to={backHref} className="block text-center text-sm font-medium text-primary hover:underline">
          {backLabel}
        </Link>
      }
    >
      <form className="space-y-6" onSubmit={handleVerify} noValidate>
        <OtpInput length={6} value={code} onChange={setCode} error={Boolean(error)} disabled={submitting} />
        {error && <p className="text-center text-sm text-danger">{error}</p>}

        <Button type="submit" disabled={code.length !== 6 || submitting}>
          {submitting ? "Verifying…" : "Verify"}
        </Button>

        {/* No resend for mfa — the code is generated locally by the user's
            authenticator app, not sent by the platform. */}
        {!isMfa && (
          <div className="text-center text-sm text-text/60">
            {cooldown > 0 ? (
              <span>Resend in 0:{String(cooldown).padStart(2, "0")}</span>
            ) : (
              <button
                type="button"
                onClick={handleResend}
                className="font-medium text-primary hover:underline"
              >
                Resend code
              </button>
            )}
          </div>
        )}
      </form>
    </AuthCard>
  );
}
